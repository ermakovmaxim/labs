#!/usr/bin/perl

# Run from inside HTML documents directory to create poco.qhp
# Then run "qcollectiongenerator poco.qhcp -o poco.qhc"


use strict;
use Mojo::DOM;
use File::Find;

open IF, "overview.html" or die "Can't open overview.html: $!\n";
my $overview = do { local($/); <IF>};
close IF;

open IF, "index-all.html" or die "Can't open index-all.html: $!\n";
my $indexall = do { local($/); <IF>};
close IF;

my $dom = Mojo::DOM->new;
$dom->parse($overview);

open OF, ">poco.qhp" or die "Can't create poco.qhp: $!\n";

print OF "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n";
print OF "<QtHelpProject version=\"1.0\">\n";
print OF "  <namespace>org.pocoproject.1.0</namespace>\n";
print OF "  <virtualFolder>poco</virtualFolder>\n";
print OF "  <customFilter name=\"Poco\">\n";
print OF "    <filterAttribute>poco</filterAttribute>\n";
print OF "  </customFilter>\n";
print OF "  <filterSection>\n";
print OF "    <filterAttribute>poco</filterAttribute>\n";
print OF "    <toc>\n";

my $depth = 0;
for my $s ($dom->find('h4,li')->each) {
    if($s->type eq 'h4') {
        if($depth > 0) {
            $depth--;
            print OF "    </section>\n";
        }
        $depth++;
        print OF "    <section title=\"", $s->all_text, "\"";
        my $kids = $s->children;
        if($kids->size && $kids->first->type eq 'a') {
            print OF " ref=\"", $kids->first->attrs('href'), "\"";
        }
        print OF ">\n";
    }
    if($s->type eq 'li') {
        for my $k ($s->children->each) {
            if($k->type eq 'b') {
                if($depth > 1) {
                    $depth--;
                    print OF "      </section>\n";
                }
                $depth++;
                print OF "      <section title=\"", $k->text, "\">\n";
            }
            if($k->type eq 'a') {
                print OF "        <section title=\"", $k->text, "\" ref=\"", $k->attrs('href'), "\"/>\n";
            }
        }
    }
}
while($depth > 0) {
    print OF "  " x $depth, "</section>\n";
    $depth--;
}



print OF "    </toc>\n";
print OF "    <keywords>\n";

$dom->parse($indexall);

my %keywords;
for my $s ($dom->find('a')->each) {
    my $text = $s->text;
    $text =~ s/[^\x{21}-\x{7E}\s\t]/ /g;
    $text =~ s/&/&amp;/g;
    $text =~ s/</&lt;/g;
    $text =~ s/>/&gt;/g;
    $keywords{"      <keyword name=\"$text\" ref=\"" . $s->attrs('href') . "\" />\n"} = 1;
}
print OF join '', sort keys %keywords;

print OF "    </keywords>\n";
print OF "    <files>\n";

find({ wanted => \&wanted, no_chdir => 1}, '.');

print OF "    </files>\n";
print OF "  </filterSection>\n";
print OF "</QtHelpProject>\n";

print "Now run: qcollectiongenerator poco.qhcp -o poco.qhc\n";

sub wanted {
    return unless -f $_;
    return unless /\.(html|gif|jpg|css|js|png)$/;
    s/^\.\///;
    print OF "      <file>$_</file>\n";
}
